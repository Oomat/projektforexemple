package com.company;

public class Worker extends Position{
}
