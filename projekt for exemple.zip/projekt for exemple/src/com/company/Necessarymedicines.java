package com.company;

public class Necessarymedicines {
    public static String name[] = {"Алимемазин\n"+
            "Алирокумаб\n"+
            "Алкафтадин\n"+
            "Алкилсульфонаты\n"+
            "Аллантоин\n"+
            "Аллапинин\n"};
    public void as2(){
        for (int i = 0; i < name.length; i++) {
            System.out.println(name[i]);
        }
    }
}
