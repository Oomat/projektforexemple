package com.company;

public class Salesreport {
    String Sales_report = "Sold ---------- 200\n" +
            "Bought ---------- 1000\n" +
            "Marriage --------- 30";

    public void as3() {
            System.out.println(Sales_report);
        }
    }
