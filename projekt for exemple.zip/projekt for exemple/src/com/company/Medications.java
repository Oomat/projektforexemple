package com.company;

import java.util.ArrayList;
import java.util.List;

public class Medications {
   public static String name[] = { "Абакавир/Долутегравир/Ламивудин\n"+
            "Абакавир\n" +
            "Абакавир\n" +
            "Абилифай\n" +
            "Абитаксел\n" +
            "Аванафил\n" +
            "Авандия\n" +
            "Авастин\n" +
            "Авелокс\n" +
            "Авестатин\n" +
            "Авибактам\n" +
            "Аген\n" +
            "Агомелатин\n" +
            "Агриппал S1\n" +
            "Адалат\n" +
            "Адалимумаб\n" +
            "Адамантилбромфениламин\n" +
            "Адапромин\n" +
            "Аддералл\n" +
            "Аденозин\n" +
            "Адефовир\n" +
            "Адифенин\n" +
            "Адреналин\n" +
            "Азаметония бромид\n" +
            "Азаран"};
   public void a (){
       for (int i = 0; i < name.length; i++) {
           System.out.println(name[i]);
       }
   }
    }