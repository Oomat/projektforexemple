package com.company;

public class Manager extends Position{
}
