package com.company;

public class Main {

    public static void main(String[] args) {
        Position position = new Position();
        position.method();
//        Medications medications = new Medications();
//        medications.a();
//        Necessarymedicines necessarymedicines = new Necessarymedicines();
//        necessarymedicines.as2();


//        Illness illness = new Illness();
//        System.out.println(illness.med("Headaches"));
//        System.out.println(illness.med("Allergies"));
//        System.out.println(illness.med("Colds and Flu"));
//        System.out.println(illness.med("Stomach Aches"));
//        System.out.println(illness.med("sdsad"));
    }
}